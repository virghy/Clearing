﻿Public Class Rpt_Detalle_Documentos

    Private Sub Rpt_Detalle_Documentos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'DsReportes.Detalle_Documentos_Bancos' Puede moverla o quitarla según sea necesario.
        'TODO: esta línea de código carga datos en la tabla 'DsReportes.Bancos' Puede moverla o quitarla según sea necesario.
        Me.BancosTableAdapter.Fill(Me.DsReportes.Bancos)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If Not My.MyApplication.Cerrado(My.Application.Banco.cod_banco, DateTimePicker1.Text, My.Application.Moneda.cod_moneda, 2) Then
            MsgBox("No puede realizar esta operacion. Debe cerrar el proceso primero.", MsgBoxStyle.Information)
            Return
        End If

        Dim fecha As Date = Convert.ToDateTime(Me.DateTimePicker1.Text)
        Dim entidad As String = Nothing

        If Not Me.ComboBox2.SelectedValue Is Nothing Then
            entidad = Me.ComboBox2.SelectedValue
        End If


        Me.Rpt_DetalleChequesTableAdapter.Fill(DsReportes.rpt_DetalleCheques, My.Settings.IdEmpresa, fecha, entidad, My.Settings.Moneda)

        Dim lParam As New List(Of Microsoft.Reporting.WinForms.ReportParameter)
        lParam.Add(New Microsoft.Reporting.WinForms.ReportParameter("NombreBanco", My.Application.Banco.nombre_banco))
        lParam.Add(New Microsoft.Reporting.WinForms.ReportParameter("Mascara", "N" + My.Application.Moneda.decimales.ToString))

        If My.Settings.CalidadImpresion Is Nothing Then
            My.Settings.CalidadImpresion = "F"
            My.Settings.Save()
        End If

        lParam.Add(New Microsoft.Reporting.WinForms.ReportParameter("CalidadImpresion", My.Settings.CalidadImpresion))

        Me.ReportViewer1.LocalReport.SetParameters(lParam)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class