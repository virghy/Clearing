﻿Public Class rpt_Cheques_Cargo_Interbanco_mmayor

    Private Sub rpt_Cheques_Cargo_Interbanco_mmayor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'dsReportes.Cheques_cargo_Interbanco_mayores' Puede moverla o quitarla según sea necesario.
        '     Me.Cheques_cargo_Interbanco_mayoresTableAdapter.Fill(Me.dsReportes.Cheques_cargo_Interbanco_mayores)

    End Sub

End Class