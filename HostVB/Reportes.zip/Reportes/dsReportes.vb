﻿Partial Class dsReportes
End Class

Namespace dsReportesTableAdapters
    
    Partial Public Class LecturasTableAdapter
    End Class
End Namespace
