﻿
Public Class Reportes
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Me.RadioButton1.Checked = True Then
  
            Dim Frm As New Rpt_Detalle_Documentos
            Frm.Show()
        End If

        If Me.RadioButton2.Checked = True Then
            Dim frm As New Rpt_Consolidada_CamaraCompensadora
            frm.Show()
        End If

        If Me.RadioButton3.Checked = True Then
            Dim frm As New Res_comp_Cheques_enviados
            frm.Show()
        End If
        If Me.RadioButton5.Checked = True Then
            Dim frm As New Rpt_EAvisoDebito
            frm.Show()
        End If
        If Me.RadioButton6.Checked Then
            Dim frm As New frmResumenServicio
            frm.Show()
        End If
        If Me.RadioButton7.Checked Then
            Dim frm As New Rpt_EConsolidada_Sucursal
            frm.Show()
        End If

    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub RadioButton7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton7.CheckedChanged

    End Sub
End Class